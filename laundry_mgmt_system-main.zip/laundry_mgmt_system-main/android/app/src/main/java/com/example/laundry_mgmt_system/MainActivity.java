package com.example.laundry_mgmt_system;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
